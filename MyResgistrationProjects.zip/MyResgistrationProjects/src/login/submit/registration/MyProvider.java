 package login.submit.registration;
 


public interface MyProvider {
	String username="root";
	String pwd="Rockguy@00";
	String connURL="jdbc:mysql://127.0.0.1:3306/loginDB?useUnicode=true&characterEncoding=UTF-8&zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=CST"; //ppostgresql =>> mysql
}
  