package login.submit.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/loginRegister") 
public class LoginRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LoginRegister() {
        super();
    }
    
    
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CustomerDAO cd = new CustomerDAOImpl();
		String userName = request.getParameter("username");
		String password = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		// needed to check password
		int count = 0;
		int upper_count = 0;
		int lower_count = 0;
		int symbol_count = 0;
		int number_count = 0;
		String Uletters = "AEIOUQWRTYPSDFGHJKLZXCVBNM";
		String Lletters = "aeiouqwrtypsdfghjklzxcvbnm";
		String numbers = "0123456789";
		String symbols = "!@#$&*";
		
		String submitType = request.getParameter("submit");
		Customer c = cd.getCustomer(userName, password);
		
		// password requirements
		for(int i=0; i< password.length();i++) {
			char charac = password.charAt(i);
			if (Uletters.indexOf(""+charac) != -1) {
				upper_count += 1;
			}
			else if (Lletters.indexOf(""+charac) != -1) {
				lower_count += 1;
			}
			else if (numbers.indexOf(""+charac) != -1) {
				number_count += 1;
			}
			else if (symbols.indexOf(""+charac) != -1) {
				symbol_count += 1;
			}
			count += 1;
		}
		
		if (submitType.equals("Login") && c != null && c.getName() != null && c.getEmail() != null) { // if login is in database
			request.setAttribute("message", c.getName());
			request.getRequestDispatcher("welcome.jsp").forward(request, response);
			
			
		}else if (submitType.equals("Register")) { // when registration is clicked
			if (!password.equals(password2)) { // checks if two passwords are equal
				request.setAttribute("message", "Passwords Do Not Match. Try Again.");
				request.getRequestDispatcher("register.jsp").forward(request, response);
				return;
			}
			
			else if (c.getUsername() == null){ // username not taken
				if (count < 5 || lower_count == 0 || upper_count == 0 || number_count == 0 || symbol_count == 0) { // checks if password requirements are met
					
					request.setAttribute("pass1", "Password Needs to be Atleast 6 characters");
					request.setAttribute("pass2", "Needs to include Atleast One Uppercase letter, One Lowercase letter");
					request.setAttribute("pass3", "Needs to include Atleast One Number, One Symbol (!@#$&*)");
					request.getRequestDispatcher("register.jsp").forward(request, response);
					return;
					
				}
				else { // registration complete
					c.setName(name);
					c.setPassword(password);
					c.setUsername(userName);
					c.setEmail(email);
					System.out.println("this is username:" + userName);
					System.out.println("this is name:" + c.getName());
					System.out.println("this is password:" + password);
					cd.insertCustomer(c);
					request.setAttribute("successMessage", "Get Hype!! Now Login to Continue.");
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
			}
			else { // username is taken
				request.setAttribute("message", "Username is taken, Try Again.");
				request.getRequestDispatcher("register.jsp").forward(request, response);
			}
		}
		else { // Either wrong username and password OR No Account
			request.setAttribute("message", "Data Not Found, Either Wrong Password or Username.");
			request.setAttribute("message2", "Don't have an Account? Then Register Today!");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}

		
		
		
		
		
	}

}
